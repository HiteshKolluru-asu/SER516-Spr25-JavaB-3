package com.example;

import com.example.service.UserService;

public class MainApplication {
    public static void main(String[] args) {
        UserService userService = new UserService();
        userService.registerUser("John Doe");
    }
}