package com.example.service;

import com.example.model.User;
import com.example.repository.UserRepository;

public class UserService {
    private UserRepository userRepository = new UserRepository();

    public void registerUser(String name) {
        User user = new User(name);
        userRepository.save(user);
    }
}