package ie.gmit.sw.Controller;

public interface Mappable {
	
	void addToMap();

}
