package ie.gmit.sw.Controller;

public interface Measurable {
	
	void calculateStability();

}
